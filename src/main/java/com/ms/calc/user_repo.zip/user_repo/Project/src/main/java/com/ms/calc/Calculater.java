package com.ms.calc;

public class Calculater {

	public double doAdd(double num1, double num2) {
//		int i;
		System.out.println("test");
		return num1 + num2;
	}

	public double doSub(double num1, double num2) {
		// comment line
		return num1 - num2;
	}

	public double doMul(double num1, double num2) {
		return num1 * num2;
	}

	public double doDiv(double num1, double num2) {
		return num1 / num2;
	}

}
