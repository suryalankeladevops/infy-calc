// When the user clicks on the button, scroll to the top of the document
function scrollToTop() {
  document.body.scrollTop = 0; // For Safari
  document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
}
function showAbout() {
    document.getElementById('about_p').style.display = "block";
    document.getElementById('instructions_p').style.display = "none";
    document.getElementById('context_p').style.display = "none";
    document.getElementById('welcome_p').style.display = "none";
    document.getElementById('demos_p').style.display = "none";
    document.getElementById('exercise_p').style.display = "none";
    document.getElementById('capstone_p').style.display = "none";
	removeSelection();
    document.getElementById('about').classList.add("tab-selected");
	scrollToTop();
}
function showContext() {
    document.getElementById('about_p').style.display = "none";
    document.getElementById('instructions_p').style.display = "none";
    document.getElementById('context_p').style.display = "block";
    document.getElementById('welcome_p').style.display = "none";
    document.getElementById('demos_p').style.display = "none";
    document.getElementById('exercise_p').style.display = "none";
    document.getElementById('capstone_p').style.display = "none";
	removeSelection();
    document.getElementById('context').classList.add("tab-selected");
	scrollToTop();
}

function showInstructions() {
    document.getElementById('about_p').style.display = "none";
	document.getElementById('instructions_p').style.display = "block";
    document.getElementById('context_p').style.display = "none";
    document.getElementById('welcome_p').style.display = "none";
    document.getElementById('demos_p').style.display = "none";
    document.getElementById('exercise_p').style.display = "none";
    document.getElementById('capstone_p').style.display = "none";
	removeSelection();
    document.getElementById('instructions').classList.add("tab-selected");
	scrollToTop();
}
function showWelcome() {
    document.getElementById('about_p').style.display = "none";
    document.getElementById('instructions_p').style.display = "none";
    document.getElementById('context_p').style.display = "none";
    document.getElementById('welcome_p').style.display = "block";
    document.getElementById('demos_p').style.display = "none";
    document.getElementById('exercise_p').style.display = "none";
    document.getElementById('capstone_p').style.display = "none";
	removeSelection();
    document.getElementById('welcome').classList.add("tab-selected");
	scrollToTop();
}
function showDemos() {
    document.getElementById('about_p').style.display = "none";
    document.getElementById('instructions_p').style.display = "none";
    document.getElementById('context_p').style.display = "none";
    document.getElementById('welcome_p').style.display = "none";
    document.getElementById('demos_p').style.display = "block";
    document.getElementById('exercise_p').style.display = "none";
    document.getElementById('capstone_p').style.display = "none";
	removeSelection();
    document.getElementById('demos').classList.add("tab-selected");
	scrollToTop();
}

function showExercises() {
    document.getElementById('about_p').style.display = "none";
    document.getElementById('instructions_p').style.display = "none";
    document.getElementById('context_p').style.display = "none";
    document.getElementById('welcome_p').style.display = "none";
    document.getElementById('demos_p').style.display = "none";
    document.getElementById('exercise_p').style.display = "block";
    document.getElementById('capstone_p').style.display = "none";
	removeSelection();
    document.getElementById('exercises').classList.add("tab-selected");
	scrollToTop();
}

function showCapstone() {
    document.getElementById('about_p').style.display = "none";
    document.getElementById('instructions_p').style.display = "none";
    document.getElementById('context_p').style.display = "none";
    document.getElementById('welcome_p').style.display = "none";
    document.getElementById('demos_p').style.display = "none";
    document.getElementById('exercise_p').style.display = "none";
    document.getElementById('capstone_p').style.display = "block";
	removeSelection();
    document.getElementById('capstone').classList.add("tab-selected");
	scrollToTop();
}
function removeSelection(){
    document.getElementById('about').classList.remove("tab-selected");
    document.getElementById('demos').classList.remove("tab-selected");
    document.getElementById('welcome').classList.remove("tab-selected");
    document.getElementById('exercises').classList.remove("tab-selected");
    document.getElementById('instructions').classList.remove("tab-selected");
	document.getElementById('context').classList.remove("tab-selected");
    document.getElementById('capstone').classList.remove("tab-selected");
}
//On page load show About section by default
$(document).ready( function (){
	showAbout();
});
